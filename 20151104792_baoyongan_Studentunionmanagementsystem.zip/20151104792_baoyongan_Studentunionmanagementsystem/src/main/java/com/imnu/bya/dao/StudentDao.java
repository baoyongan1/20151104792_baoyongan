package com.imnu.bya.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.imnu.bya.pojo.Student;

public interface StudentDao {
	
	//登录的方法
	@Select("SELECT * FROM demo.stu a,demo.dep b WHERE a.StuId=#{id} AND a.StuPwd=#{pwd} AND a.StuDepartName=b.DepNo")
	@Results({
		@Result(property="StuNo",column="StuNo"),
		@Result(property="StuName",column="StuName"),
		@Result(property="StuSex",column="StuSex"),
		@Result(property="StuPosition",column="StuPosition"),
		@Result(property="StuDepartName.DepName",column="DepName"),
		@Result(property="StuMajor",column="StuMajor"),
		@Result(property="StuGrade",column="StuGrade"),
		@Result(property="StuPhoneNo",column="StuPhoneNo"),
		@Result(property="StuStaTime",column="StuStaTime"),
		@Result(property="StuCaseS",column="StuCaseS"),
		@Result(property="StuFlag",column="StuFlag"),
		@Result(property="StuId",column="StuId"),
		@Result(property="StuPwd",column="StuPwd")
	})
	public Student login(@Param("id")String id,@Param("pwd")String pwd);
	
	//查询所有学生信息
	@Select("SELECT * FROM demo.stu a,demo.dep b WHERE a.StuDepartName=b.DepNo")
	@Results({
		@Result(property="StuNo",column="StuNo"),
		@Result(property="StuName",column="StuName"),
		@Result(property="StuSex",column="StuSex"),
		@Result(property="StuPosition",column="StuPosition"),
		@Result(property="StuDepartName.DepName",column="DepName"),
		@Result(property="StuMajor",column="StuMajor"),
		@Result(property="StuGrade",column="StuGrade"),
		@Result(property="StuPhoneNo",column="StuPhoneNo"),
		@Result(property="StuStaTime",column="StuStaTime"),
		@Result(property="StuCaseS",column="StuCaseS"),
		@Result(property="StuFlag",column="StuFlag"),
		@Result(property="StuId",column="StuId"),
		@Result(property="StuPwd",column="StuPwd")
	})
	public List<Student> selectAllStudent();
	
	//修改学生权限的方法
	@Update("UPDATE demo.stu SET StuFlag=#{StuFlag} WHERE StuNo=#{StuNo}")
	public int updateStuFlag(Student stu);
	
}
