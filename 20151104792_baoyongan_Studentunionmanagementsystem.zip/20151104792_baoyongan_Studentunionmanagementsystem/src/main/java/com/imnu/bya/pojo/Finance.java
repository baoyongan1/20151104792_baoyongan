package com.imnu.bya.pojo;

import java.util.Date;

public class Finance {
	private int FinNo;
	private String FinPurpose;
	private int FinMoney;
	private String FinPerson;
	private int FinDepartment;
	private Date FinTime;
	private int FinRemain;
	public int getFinNo() {
		return FinNo;
	}
	public void setFinNo(int finNo) {
		FinNo = finNo;
	}
	public String getFinPurpose() {
		return FinPurpose;
	}
	public void setFinPurpose(String finPurpose) {
		FinPurpose = finPurpose;
	}
	public int getFinMoney() {
		return FinMoney;
	}
	public void setFinMoney(int finMoney) {
		FinMoney = finMoney;
	}
	public String getFinPerson() {
		return FinPerson;
	}
	public void setFinPerson(String finPerson) {
		FinPerson = finPerson;
	}
	public int getFinDepartment() {
		return FinDepartment;
	}
	public void setFinDepartment(int finDepartment) {
		FinDepartment = finDepartment;
	}
	public Date getFinTime() {
		return FinTime;
	}
	public void setFinTime(Date finTime) {
		FinTime = finTime;
	}
	public int getFinRemain() {
		return FinRemain;
	}
	public void setFinRemain(int finRemain) {
		FinRemain = finRemain;
	}
	@Override
	public String toString() {
		return "Finance [FinNo=" + FinNo + ", FinPurpose=" + FinPurpose + ", FinMoney=" + FinMoney + ", FinPerson="
				+ FinPerson + ", FinDepartment=" + FinDepartment + ", FinTime=" + FinTime + ", FinRemain=" + FinRemain
				+ "]";
	}
	
}
