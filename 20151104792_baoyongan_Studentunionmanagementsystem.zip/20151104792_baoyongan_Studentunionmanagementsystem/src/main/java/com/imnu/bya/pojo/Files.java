package com.imnu.bya.pojo;

import java.util.Date;

public class Files {
	private int FilesNo;
	private String FilesName;
	private String FilesType;
	private int FilesBelDep;
	private String FilesPerson;
	private String RecDisPartner;
	private Date ArcDate;
	private String Remarks;
	public int getFilesNo() {
		return FilesNo;
	}
	public void setFilesNo(int filesNo) {
		FilesNo = filesNo;
	}
	public String getFilesName() {
		return FilesName;
	}
	public void setFilesName(String filesName) {
		FilesName = filesName;
	}
	public String getFilesType() {
		return FilesType;
	}
	public void setFilesType(String filesType) {
		FilesType = filesType;
	}
	public int getFilesBelDep() {
		return FilesBelDep;
	}
	public void setFilesBelDep(int filesBelDep) {
		FilesBelDep = filesBelDep;
	}
	public String getFilesPerson() {
		return FilesPerson;
	}
	public void setFilesPerson(String filesPerson) {
		FilesPerson = filesPerson;
	}
	public String getRecDisPartner() {
		return RecDisPartner;
	}
	public void setRecDisPartner(String recDisPartner) {
		RecDisPartner = recDisPartner;
	}
	public Date getArcDate() {
		return ArcDate;
	}
	public void setArcDate(Date arcDate) {
		ArcDate = arcDate;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	@Override
	public String toString() {
		return "Files [FilesNo=" + FilesNo + ", FilesName=" + FilesName + ", FilesType=" + FilesType + ", FilesBelDep="
				+ FilesBelDep + ", FilesPerson=" + FilesPerson + ", RecDisPartner=" + RecDisPartner + ", ArcDate="
				+ ArcDate + ", Remarks=" + Remarks + "]";
	}
	
}
