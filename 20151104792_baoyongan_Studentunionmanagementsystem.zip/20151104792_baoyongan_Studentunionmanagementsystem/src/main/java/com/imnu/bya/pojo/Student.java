package com.imnu.bya.pojo;

import java.util.Date;

public class Student {
	private int StuNo;
	private String StuName;
	private String StuSex;
	private String StuPosition;
	private Dept StuDepartName;
	private String StuMajor;
	private String StuGrade;
	private String StuPhoneNo;
	private Date StuStaTime;
	private String StuCaseS;
	private int StuFlag;
	private String StuId;
	private String StuPwd;
	public int getStuNo() {
		return StuNo;
	}
	public void setStuNo(int stuNo) {
		StuNo = stuNo;
	}
	public String getStuName() {
		return StuName;
	}
	public void setStuName(String stuName) {
		StuName = stuName;
	}
	public String getStuSex() {
		return StuSex;
	}
	public void setStuSex(String stuSex) {
		StuSex = stuSex;
	}
	public String getStuPosition() {
		return StuPosition;
	}
	public void setStuPosition(String stuPosition) {
		StuPosition = stuPosition;
	}
	public Dept getStuDepartName() {
		return StuDepartName;
	}
	public void setStuDepartName(Dept stuDepartName) {
		StuDepartName = stuDepartName;
	}
	public String getStuMajor() {
		return StuMajor;
	}
	public void setStuMajor(String stuMajor) {
		StuMajor = stuMajor;
	}
	public String getStuGrade() {
		return StuGrade;
	}
	public void setStuGrade(String stuGrade) {
		StuGrade = stuGrade;
	}
	public String getStuPhoneNo() {
		return StuPhoneNo;
	}
	public void setStuPhoneNo(String stuPhoneNo) {
		StuPhoneNo = stuPhoneNo;
	}
	public Date getStuStaTime() {
		return StuStaTime;
	}
	public void setStuStaTime(Date stuStaTime) {
		StuStaTime = stuStaTime;
	}
	public String getStuCaseS() {
		return StuCaseS;
	}
	public void setStuCaseS(String stuCaseS) {
		StuCaseS = stuCaseS;
	}
	public int getStuFlag() {
		return StuFlag;
	}
	public void setStuFlag(int stuFlag) {
		StuFlag = stuFlag;
	}
	public String getStuId() {
		return StuId;
	}
	public void setStuId(String stuId) {
		StuId = stuId;
	}
	public String getStuPwd() {
		return StuPwd;
	}
	public void setStuPwd(String stuPwd) {
		StuPwd = stuPwd;
	}
	@Override
	public String toString() {
		return "Student [StuNo=" + StuNo + ", StuName=" + StuName + ", StuSex=" + StuSex + ", StuPosition="
				+ StuPosition + ", StuDepartName=" + StuDepartName + ", StuMajor=" + StuMajor + ", StuGrade=" + StuGrade
				+ ", StuPhoneNo=" + StuPhoneNo + ", StuStaTime=" + StuStaTime + ", StuCaseS=" + StuCaseS + ", StuFlag="
				+ StuFlag + ", StuId=" + StuId + ", StuPwd=" + StuPwd + "]";
	}
	
}
