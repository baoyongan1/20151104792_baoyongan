package com.imnu.bya.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.imnu.bya.pojo.Student;
import com.imnu.bya.service.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService ss;
	
	//登录的方法
	@GetMapping("/login")
	public ResponseEntity<?> login(@RequestParam("id")String id,@RequestParam("pwd")String pwd,HttpSession hs){
		Student stu = ss.login(id, pwd);
		ResponseEntity<Student> res = null;
		if(stu==null) {
			res = new ResponseEntity<Student>(new Student(),HttpStatus.BAD_REQUEST);
			return res;
		}else {
			hs.setAttribute("stu", stu);
			res = new ResponseEntity<Student>(stu,HttpStatus.OK);
			return res;
		}
	}
	
	//获得当前登录学生的信息
	@PostMapping("/selectStudent")
	public ResponseEntity<?> selectStudent(HttpSession session) {
		Student stu=(Student) session.getAttribute("stu");
		ResponseEntity<Student> res = new ResponseEntity<Student>(stu,HttpStatus.OK);
		return res;
	}
	
	//查询所有学生的方法
	@GetMapping("/selectAllStudent")
	public ResponseEntity<?> selectAllStudent(){
		List<Student> list = ss.selectAllStudent();
		ResponseEntity<List<Student>> res=null;
		if(list!=null) {
			res=new ResponseEntity<List<Student>>(list,HttpStatus.OK);
			return res;
		}else {
			res=new ResponseEntity<List<Student>>(list,HttpStatus.BAD_REQUEST);
			return res;
		}
	}
	
}
