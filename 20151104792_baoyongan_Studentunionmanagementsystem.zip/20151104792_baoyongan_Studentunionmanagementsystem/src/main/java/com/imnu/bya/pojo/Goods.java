package com.imnu.bya.pojo;

import java.util.Date;

public class Goods {
	private int GoodsNo;
	private String GoodsName;
	private Date GoodsBuyTime;
	private int GoodsPrice;
	private Date GoodsLendTime;
	private String GoodsLender;
	private String GoodsReturner;
	private Date GoodsRetTime;
	public int getGoodsNo() {
		return GoodsNo;
	}
	public void setGoodsNo(int goodsNo) {
		GoodsNo = goodsNo;
	}
	public String getGoodsName() {
		return GoodsName;
	}
	public void setGoodsName(String goodsName) {
		GoodsName = goodsName;
	}
	public Date getGoodsBuyTime() {
		return GoodsBuyTime;
	}
	public void setGoodsBuyTime(Date goodsBuyTime) {
		GoodsBuyTime = goodsBuyTime;
	}
	public int getGoodsPrice() {
		return GoodsPrice;
	}
	public void setGoodsPrice(int goodsPrice) {
		GoodsPrice = goodsPrice;
	}
	public Date getGoodsLendTime() {
		return GoodsLendTime;
	}
	public void setGoodsLendTime(Date goodsLendTime) {
		GoodsLendTime = goodsLendTime;
	}
	public String getGoodsLender() {
		return GoodsLender;
	}
	public void setGoodsLender(String goodsLender) {
		GoodsLender = goodsLender;
	}
	public String getGoodsReturner() {
		return GoodsReturner;
	}
	public void setGoodsReturner(String goodsReturner) {
		GoodsReturner = goodsReturner;
	}
	public Date getGoodsRetTime() {
		return GoodsRetTime;
	}
	public void setGoodsRetTime(Date goodsRetTime) {
		GoodsRetTime = goodsRetTime;
	}
	@Override
	public String toString() {
		return "Goods [GoodsNo=" + GoodsNo + ", GoodsName=" + GoodsName + ", GoodsBuyTime=" + GoodsBuyTime
				+ ", GoodsPrice=" + GoodsPrice + ", GoodsLendTime=" + GoodsLendTime + ", GoodsLender=" + GoodsLender
				+ ", GoodsReturner=" + GoodsReturner + ", GoodsRetTime=" + GoodsRetTime + "]";
	}
	
}
