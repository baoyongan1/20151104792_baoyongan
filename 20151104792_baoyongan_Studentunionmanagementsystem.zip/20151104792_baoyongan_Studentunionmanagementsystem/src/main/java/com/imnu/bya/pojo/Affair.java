package com.imnu.bya.pojo;

public class Affair {
	private int AffNo;
	private String AffName;
	private String AffScope;
	private int AffDepartment;
	private String AffScheme;
	private String AffQuality;
	public int getAffNo() {
		return AffNo;
	}
	public void setAffNo(int affNo) {
		AffNo = affNo;
	}
	public String getAffName() {
		return AffName;
	}
	public void setAffName(String affName) {
		AffName = affName;
	}
	public String getAffScope() {
		return AffScope;
	}
	public void setAffScope(String affScope) {
		AffScope = affScope;
	}
	public int getAffDepartment() {
		return AffDepartment;
	}
	public void setAffDepartment(int affDepartment) {
		AffDepartment = affDepartment;
	}
	public String getAffScheme() {
		return AffScheme;
	}
	public void setAffScheme(String affScheme) {
		AffScheme = affScheme;
	}
	public String getAffQuality() {
		return AffQuality;
	}
	public void setAffQuality(String affQuality) {
		AffQuality = affQuality;
	}
	@Override
	public String toString() {
		return "Affair [AffNo=" + AffNo + ", AffName=" + AffName + ", AffScope=" + AffScope + ", AffDepartment="
				+ AffDepartment + ", AffScheme=" + AffScheme + ", AffQuality=" + AffQuality + "]";
	}
	
}
