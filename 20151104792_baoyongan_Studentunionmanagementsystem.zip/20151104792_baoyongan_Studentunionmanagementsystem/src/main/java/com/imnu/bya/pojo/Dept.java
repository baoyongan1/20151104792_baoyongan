package com.imnu.bya.pojo;

public class Dept {
	private int DepNo;
	private String DepName;
	private String DepMinName;
	private int DepSminSum;
	private int DepMemSum;
	private long MinPhoNo;
	public int getDepNo() {
		return DepNo;
	}
	public void setDepNo(int depNo) {
		DepNo = depNo;
	}
	public String getDepName() {
		return DepName;
	}
	public void setDepName(String depName) {
		DepName = depName;
	}
	public String getDepMinName() {
		return DepMinName;
	}
	public void setDepMinName(String depMinName) {
		DepMinName = depMinName;
	}
	public int getDepSminSum() {
		return DepSminSum;
	}
	public void setDepSminSum(int depSminSum) {
		DepSminSum = depSminSum;
	}
	public int getDepMemSum() {
		return DepMemSum;
	}
	public void setDepMemSum(int depMemSum) {
		DepMemSum = depMemSum;
	}
	public long getMinPhoNo() {
		return MinPhoNo;
	}
	public void setMinPhoNo(long minPhoNo) {
		MinPhoNo = minPhoNo;
	}
	@Override
	public String toString() {
		return "Dept [DepNo=" + DepNo + ", DepName=" + DepName + ", DepMinName=" + DepMinName + ", DepSminSum="
				+ DepSminSum + ", DepMemSum=" + DepMemSum + ", MinPhoNo=" + MinPhoNo + "]";
	}
	
}
