package com.imnu.bya.service;

import java.util.List;

import com.imnu.bya.pojo.Student;

public interface StudentService {
	
	//登录的方法
	public Student login(String id,String pwd);
	
	//查询所有学生信息
	public List<Student> selectAllStudent();
	
}
