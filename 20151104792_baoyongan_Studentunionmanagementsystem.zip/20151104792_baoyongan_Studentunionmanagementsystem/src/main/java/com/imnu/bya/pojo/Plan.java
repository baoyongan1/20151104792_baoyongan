package com.imnu.bya.pojo;

import java.util.Date;

public class Plan {
	private int PlaNo;
	private String PlaName;
	private int PlaDepartment;
	private String PlaPerson;
	private Date PlaTime;
	private int PlaQuality;
	public int getPlaNo() {
		return PlaNo;
	}
	public void setPlaNo(int plaNo) {
		PlaNo = plaNo;
	}
	public String getPlaName() {
		return PlaName;
	}
	public void setPlaName(String plaName) {
		PlaName = plaName;
	}
	public int getPlaDepartment() {
		return PlaDepartment;
	}
	public void setPlaDepartment(int plaDepartment) {
		PlaDepartment = plaDepartment;
	}
	public String getPlaPerson() {
		return PlaPerson;
	}
	public void setPlaPerson(String plaPerson) {
		PlaPerson = plaPerson;
	}
	public Date getPlaTime() {
		return PlaTime;
	}
	public void setPlaTime(Date plaTime) {
		PlaTime = plaTime;
	}
	public int getPlaQuality() {
		return PlaQuality;
	}
	public void setPlaQuality(int plaQuality) {
		PlaQuality = plaQuality;
	}
	@Override
	public String toString() {
		return "Plan [PlaNo=" + PlaNo + ", PlaName=" + PlaName + ", PlaDepartment=" + PlaDepartment + ", PlaPerson="
				+ PlaPerson + ", PlaTime=" + PlaTime + ", PlaQuality=" + PlaQuality + "]";
	}
	
}
