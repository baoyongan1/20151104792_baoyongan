package com.imnu.bya.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.imnu.bya.dao.StudentDao;
import com.imnu.bya.pojo.Student;
import com.imnu.bya.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentDao sd;
	
	@Override
	public Student login(String id, String pwd) {
		return sd.login(id, pwd);
	}

	@Override
	public List<Student> selectAllStudent() {
		return sd.selectAllStudent();
	}

}
